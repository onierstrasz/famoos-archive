/*
 * This file is part of sniff2famix
 * Copyright (C) 1999  Sander Tichelaar, tichel@iam.unibe.ch
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
 * USA.
 */ 

/************************************************************************
 * File: extractor.c
 * 
 * Description: 
 * 
 *    extractor.c implements extractor.h. It uses the SNiFF+ API to
 *    produce from a SNiFF+ symbol table the FAMIX model in
 *    CDIF.
 *
 *    For more information about the FAMOOS model and the CDIF format,
 *    see:  
 *      http://www.iam.unibe.ch/~famoos/InfoExchFormat/
 *
 *    The current version can show everything up till level 3 completely,
 *    and from level 4 this extractor shows the following things:
 *      - FormalParameters
 *
 * Version history:
 * 
 *   28.06.97: First version based on a previous version that tried
 *             an immediate access from Smalltalk of the SNiFF_API by
 *             Serge Demeyer.
 *   13.08.98: version 1.0 frozen
 *
 *   31.03.99: added check and skip for superclasses with name "*"
 *             (happens in SNiFF+ 3.0 and higher)
 *   06.04.99: adapted createSignature to add "const" at the end of the
 *             signature for const methods and functions (needed for
 *             unique naming, see C++ plugin).
 *             added showCDIFHeader and according code for toggling
 *             the header on or off.
 *             added publisherName and according code for setting name
 *             of publisher globally.
 *   29.04.99: "const" before parameters is now kept in the signature (as
 *             it should).
 *             global constants (const int SOMETHING = 3) are now
 *             taken into account (both their declarations and
 *             accesses to them).
 *   05.05.99: added check in enumerateSymbolTableUsingImplementationFiles,
 *             if file is about to be processed twice (which eliminates the 
 *             influence of the bug that the eQImplFiles query returns the
 *             list of implementation files twice; this bug is announced to 
 *             be fixed in SNiFF+ 3.1).
 *   14.06.99: Version 1.1 frozen, renamed to sniff2famix, added GNU
 *             licence stuff.
 *
 ************************************************************************/

#include "extractor.h"

/*--includes necessary for Linking with SNiFF API--*/
#include <c_symTab_API.h>

#include <stdio.h>
#include <string.h>
#include <sys/types.h> // for time
#include <time.h>

//------------------- Printing debug information ------------
#define printDebugInfo 0
// set to 0 to avoid printing debugging strings (default)
// set to 1 to print the debugging strings


#if printDebugInfo
#define debugMsgStr(str) \
    fprintf (stderr, str)

#define debugMsgStrStr(str1, str2) \
    fprintf (stderr, str1, str2)

#define debugMsgStrStrInt(str1, str2, int1) \
    fprintf (stderr, str1, str2, int1)

#define debugMsgStrInt(str, i) \
    fprintf (stderr, str, i)

#define debugMsgStrStrStr(str1, str2, str3) \
    fprintf (stderr, str1, str2, str3)

#else
#define debugMsgStr(str) 

#define debugMsgStrStr(str1, str2) 

#define debugMsgStrStrInt(str1, str2, int1) 

#define debugMsgStrInt(str, i) 

#define debugMsgStrStrStr(str1, str2, str3)

#endif

//----------------- Global variables ------------------- 

int cdifIdInt = 0; // counter for CDIF identifier. Now simply a
                   // integer that is incremented with one for every new
                   // CDIF entity. 

int level = 1; // level of reification of the FAMOOS model. Default = 1.

int showVarAccess = TRUE;
int showMethInvoc = TRUE;
int showSrcAnchor = TRUE; // if true, show source anchor, else hide. Default = TRUE.
int showPack = FALSE; // default is FALSE as the (return)type cannot
                      // contain packages yet, and therefore the output will be
                      // inconsistent, as the unique names do consist of package names

int showFullInheritanceDef = FALSE; // if true, the attrs
                                    // accessControlQualifier and index of 
                                    // InheritanceDefinition are
                                    // shown. Default = FALSE.
int showCDIFHeader = TRUE;

char publisherName[50] = "unknown";


//------ Access methods for global variables -----------

void setLevel(int lvl) { level = lvl; }
int getLevel() { return level; }

void showAccess() { showVarAccess = TRUE; }
void hideAccess() { showVarAccess = FALSE; }

void showInvocation() { showMethInvoc = TRUE; }
void hideInvocation() { showMethInvoc = FALSE; }

void showSourceAnchor() { showSrcAnchor = TRUE; }
void hideSourceAnchor() { showSrcAnchor = FALSE; }

void showPackages() { showPack = TRUE; }
void hidePackages() { showPack = FALSE; }

void showFullInheritanceDefinition() { showFullInheritanceDef = TRUE; }
void hideFullInheritanceDefinition() { showFullInheritanceDef = FALSE; }

void showHeader() { showCDIFHeader = TRUE; }
void hideHeader() { showCDIFHeader = FALSE; }

void setPublisherName(char* name) { strcpy(publisherName, name); }
char* getPublisherName() { return publisherName; }


//---------------- general helper functions ----------------

void handBackAuxBuf (HandbackSniffEntitySpec handBack, 
		     int maxAuxBuf, char* auxBuf, int lastAuxBuf)
     // see description in .h file
{
  if (lastAuxBuf > maxAuxBuf)
    debugMsgStrInt ("!!! Written beyond -eobuffer: %d", lastAuxBuf);
  debugMsgStr (auxBuf);
  // fprintf(stderr," buf = %s\n",auxBuf);
  handBack (auxBuf);
}


int checkHashed(si_Item** item_ptr) {
  // If the si_Item is hashed, it is converted into an unhashed item
  // using getHashed of the Sniff API. As this sometimes results in
  // current being null, this is being checked afterwards.
  //
  // Returns 0 if item is null after getHashed (so calling function
  // knows that is should skip this item). Returns 1 otherwise


  char name[256];
  
  strcpy(name, (*item_ptr)->name);

  if ((*item_ptr)->take._hash)
    *item_ptr = getHashed (*item_ptr);

  if (!*item_ptr) {
    //debugMsgStr("--item == NULL after getHashed\n");
    fprintf(stderr,"Warning: item %s == NULL after getHashed\n", name);

    return 0;
  }
  else return 1;
}


//--------------------- CDIF header ------------------------


int fourDigitYear(int twoDigitYear) {
  // comment this!

  if ( 70 <= twoDigitYear <= 99 )
    return (1900 + twoDigitYear);
  else
    return (2000 + twoDigitYear);
}

char* getSourceLanguage(si_Item* firstFile) {
  // typeStr of eTFile contains source language of that file. 
  // The first implementation file of the project is used to determine
  // the source language for the whole project. This might result in
  // wrong results in a hybrid project
  //
  // Note: the Sniff documentation says the declStr contains this
  // info, and the typeStr the full path of the file, but the reality
  // is vice versa (in that sense it's much like a Hollywood movie).
  
  si_Item* current = firstFile;
  if (current != NULL) {
       if (current->take._hash)
	current = getHashed (current);
       return current->take._incl->typeStr;
  }
  else return "unknown"; 
}

char* getSystemName(char* fullProjectName) {

  // TO DO: remove path from full projectname
 
  // returns name of project. For SNiFF+ the system name is the
  // projectname without it's path.
  //
  // PRE: fullProjectName contains project file name, possibly with
  // full path.

  return fullProjectName;

}


void printMinimalCDIFHeader(char* fullProjectName, si_Item* firstFile, HandbackSniffEntitySpec handBack,
		 int maxAuxBuf, char* auxBuf) {

  // Note: sysName is full name of the project file. Should be name of
  // the project, but I'm not sure I can get that info from the API.

  char appName[15]   = "sniff2famix";
  char appVersion[5] = "1.1";

  time_t seconds = time(NULL) ;
  struct tm* time = localtime(&seconds); 

  int lastAuxBuf;    


  lastAuxBuf = 0; //reset buffer	
  
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "CDIF, SYNTAX \"SYNTAX.1\" \"02.00.00\", ENCODING \"ENCODING.1\" \"02.00.00\"\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "#| This file contains a transfer with information according to the\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "   FAMOOS Information Exchange (FAMIX) Model, see\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "     http://www.iam.unibe.ch/~famoos/FAMIX/\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "   using the CDIF standard for information exchange, see\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "     http://www.eigroup.org/cdif/index.html\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "|#\n\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "(:HEADER\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "    (:SUMMARY\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "        (ExporterName     \"%s\")\n", appName);
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "        (ExporterVersion  \"%s\")\n", appVersion);
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "        (ExporterDate     \"%d/%02d/%02d\")\n", 
	                                          fourDigitYear(time->tm_year),time->tm_mon+1,time->tm_mday);
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "        (ExporterTime     \"%02d.%02d.%02d\")\n", 
	                                          time->tm_hour, time->tm_min, time->tm_sec);
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "        (PublisherName    \"%s\")\n", getPublisherName());
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "        (ParsedSystemName \"%s\")\n", getSystemName(fullProjectName));
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "        (ReificationLevel \"%d\")\n", getLevel());
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "        (SourceLanguage   \"%s\")\n", getSourceLanguage(firstFile));
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "    )\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], ")\n\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "(:META-MODEL\n\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "    (:SUBJECTAREAREFERENCE Foundation\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "        (:VERSIONNUMBER \"01.00\")\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "    )\n\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "    (:SUBJECTAREAREFERENCE FAMOOSInfExchMod\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "        (:VERSIONNUMBER \"1.1\")\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "    )\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], ")\n\n");
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "(:MODEL\n");

  handBackAuxBuf (handBack, maxAuxBuf, auxBuf, lastAuxBuf);

}


void printClosingCDIFTransfer(HandbackSniffEntitySpec handBack,
		 int maxAuxBuf, char* auxBuf) {
  // prints closing parenthesis of :MODEL section

  int lastAuxBuf;    
  
  lastAuxBuf = 0; //reset buffer	
  
  lastAuxBuf = lastAuxBuf 
    + sprintf (&auxBuf[lastAuxBuf], "\n)\n");

  handBackAuxBuf (handBack, maxAuxBuf, auxBuf, lastAuxBuf);
}


//------------------ Helper functions ----------------------

char* accessControlQualifier (si_Item* item) {
  // Returns access control qualifier of item as a CDIF string,
  // i.e. with double quotes around the control qualifier. Returns
  // CDIF null if there is no access control qualifier.  Replaces old
  // visibilityFromFlags method
  if (isPublic(item))  return "\"public\"";
  if (isPrivate(item)) return "\"private\"";
  if (isProtected(item)) return "\"protected\"";
  return "-NULL-";
}


int computeCDIFIdentifierInt() { 
  // returns the integer part of the CDIF identifier for any entity in
  // the metamodel that is exported. The CDIF identifier that is
  // produced consists of the letters FM followed by an unique
  // integer. Example: FM78. Uniqueness is ensured by just
  // incrementing the global variable cdifIdInt.
  return ++cdifIdInt; 
}




/* ***** description of si_Item->take._incl->declStr *****

   The next couple of functions extract information out of the
   si_Item->take._incl->declStr. This is the (by myself reverse
   engineered) format of the declStr:
   
   For classes:
    class @B[@Cpackage.package.@C]<classname>@B

	apparently the public keyword is not put in the declStr.	


   For methods:
    [@Istatic@I] [returnType] [* | &] [@Cpackage.package.@C][ClassName::]@BMethodName@B ( [types] ) @Iconst@I
  
   For attributes:
    [@Istatic@I] [type] [* | &] [@Cpackage.package.@C][ClassName::]@BAttributeName@B

   NOTE: A check is needed, if declStr indeed contains @B. This might
   not be the case due to bugs in the symboltable API. If there is a
   problem (i.e. no @B in the declStr) then an empty string will be
   returned. This, of course, mean inconsistency, but there is no
   other way. 

*/


void createSignature(si_Item* item, char* signature) {

  // Uses declStr (see above) 
  // Removes the possible @Istatic@I, returntype, the * or &, the @Bs
  // around the method name and the ClassName:: part to get
  // signature and puts this signature in buf and return the new
  // writePos.
  //
  // Important: "const " is part of the signature, both for the parameters
  // as for the complete method. 
  // Const methods (which means @Iconst@I at the end of declStr) have
  // a signature with const attached to it (see also C++ plugin).
  //
  // Because of the similar structure of the declStr for attributes
  // this function also nicely works for attribute names.
  //
  // This method should be able to deal with the case that () is overloaded, 
  // as in: MyType operator() (int i, int j);

  char* strippedDeclStr;
  char tmpBuf[256]; int tmpIndex = 0; // buffer to store the signature
  int len;
  char ch;
  int index;


  // check if declStr contains @B, see declStr description above. If
  // yes, strippedDeclStr contains pointer to the first occurence of @B.
  if (strippedDeclStr = strstr(item->take._incl->declStr,"@B")) {

    len = strlen(strippedDeclStr);

	// skip everything until after second @B
    
	index = 2; // skip first "@B" by setting starting index to 2
    while  ( !( (strippedDeclStr[index] == '@') && ((index +1) < len) && (strippedDeclStr[index+1] == 'B') ) ) {
	  index++; 
   	}
	index++; // -> strippedDeclStr[index] = "B"
	index++; // -> strippedDeclStr[index] first character after @B's
	
	// copy method name in tmpBuf
	strcpy(tmpBuf, item->name);
	tmpIndex = strlen(tmpBuf);
	
	// skip spaces before "(" or until end of strippedDeclStr if it doesn't contain a "("
	while (strippedDeclStr[index] == ' ') { index++; };

	// parse part with brackets and parameters "(type1, const type2,...)"
	// index start from where it left off before!
	for (index; index<len; index++) {
	  ch = strippedDeclStr[index];
 
	  // remove space behind "," and add "," to buffer
	  if ((ch == ',') && ((index +1) < len) && (strippedDeclStr[index+1] == ' ')) { 
		// add ',' and jump over space 
		tmpBuf[tmpIndex] = ch;
	    tmpIndex++;
		index++;
      }
      
      // remove space before "*" or "&"
      else if ((ch == ' ') && ((index +1) < len) && 
			   ((strippedDeclStr[index+1] == '*') ||
			   (strippedDeclStr[index+1] == '&'))
			  )  { 
			   // do nothing: space is ignored
			}
      
     else { // ch is part of signature -> put in buffer
	   tmpBuf[tmpIndex] = ch;
	   tmpIndex++;
	   if(ch==')') index=len; // ignore rest
	 }

    }
    
    tmpBuf[tmpIndex] = 0; // nicely terminate tmpBuf with a ending 0
    
  }
  // error in the SNiFF+ declStr: give warning and put empty string as
  // inconsistent, but valid information
  else {
    fprintf(stderr,"\nWARNING: empty signature returned while processing %s!\n",item->name);
    strcpy(tmpBuf,"");
    debugMsgStrStrStr(" declStr of item %s = %s\n",item->name,item->take._incl->declStr);
  }
  
  // add const to signature if method is const (needed for unique
  // naming, see upcoming C++ plugin.
  if (strstr(item->take._incl->declStr,"@Iconst@I")) {
    strcat(tmpBuf,"const");
  }    

  // finally, copy tmpBuf to varparameter signature
  strcpy(signature,tmpBuf);
  
}


void packageNameFromDeclStr(char* declStr, char* name) {
  // returns in name the information between @C's in declStr. This
  // information contains the package names in Java format

  char _declStr[256]; // local copy of declStr to use with strtok
  char* token;
  char* strippedDeclStr;
  //  char* tmpPackageName = (char*) malloc(256);
  char tmpPackageName[256];
  char finalPackageName[256];

  if (showPack) {

    strcpy(_declStr, declStr); // make local copy
    
    // check if _declStr contains @C, because then it contains a package name.
    if (strippedDeclStr  = strstr(_declStr,"@C")) {
      
       token = strtok(strippedDeclStr,"@C");  // apparently returns
       // pointer to substring that contains everything between @C and @C
 
      strcpy(tmpPackageName,token); 

      // convert dot to "::"'s to comply to the FAMIX unique naming
      // scheme
      strcpy(finalPackageName,"");
      token = strtok(tmpPackageName, ".");
      while (token ) {
		strcat(finalPackageName,token);
		strcat(finalPackageName, "::");
		token = strtok(NULL, ".");
      }

    }
    else 
      strcpy(finalPackageName,"");
  }
  else
    strcpy(finalPackageName,"");
  
  strcpy(name,finalPackageName);
}


void uniqueNameOfClass(si_Item* aClass, char* name) {

  char _packageName[256];
  char _uniqueClassName[256];
  
  packageNameFromDeclStr(aClass->take._incl->declStr, _packageName);

  strcpy(_uniqueClassName, _packageName);
  strcat(_uniqueClassName, aClass->name);

  // finally, put tmpClassName in name
  strcpy(name,_uniqueClassName);
}


void createUniqueNameOfClass(si_Item* item, char* name) {
  //strcpy(name,item->name);
  uniqueNameOfClass(item,name);
}


void createClassNameFromDeclStr(si_Item* item, char* name) {
  
  // Uses declStr from attributes or methods (see above) 
  // Removes the possible @Istatic@I, returnType, the * or & and
  // everything from "::" to get the name of the class and put this in
  // the var-parameter name. If there exists no class name (for instance, 
  // for global variables) in the declStr the returned name will be the empty 
  // string.
  
  char _declStr[256]; // local copy of declStr to use with strtok
  char* token;
  char tmpClassName[256];
  char _packageName[256];
  char _className[256];


  strcpy(_declStr,item->take._incl->declStr); // make local copy for strtok

  packageNameFromDeclStr(_declStr,_packageName);

  if ( token = strstr(_declStr, "@C")) { 

    // _declStr contains package name,
    // token points to first @C
    token = token + 2; // put pointer after @C
    token = strstr(token, "@C"); // points to second @C
    token = token + 2; // put pointer after @C
    token = strtok(token, "::"); // token should be class name
    
    strcpy(_className, token);
  }

  else {// _declStr doesn't contain package name

    // check if _declStr contains @B, see declStr description above.
    if (strstr(_declStr,"@B") ) {
      
      token = strtok(_declStr," ");  // initialize strtok
      
      // skip all tokens before [ClassName::]@BItemName@B...    
      while(!strstr(token,"@B")) { 
	token = strtok(NULL," ");
      }  
      
      if (strstr(token,"::")) { // token contains classname
	token = strtok(token,"::"); // should contain classname
	strcpy(_className ,token);
      }
      else
	strcpy(_className,""); 
    }
  // error in the SNiFF+ declStr: give warning and put empty string as
  // inconsistent, but valid information
    else {
      fprintf(stderr,"\nWARNING: empty class name returned while processing %s!\n",item->name);
      strcpy(_className,"");
      debugMsgStrStrStr(" declStr of item %s = %s\n",item->name,item->take._incl->declStr);
    }
  }

  strcpy(tmpClassName, _packageName);
  strcat(tmpClassName, _className);

  // finally, put tmpClassName in name
  strcpy(name,tmpClassName);
}


void modifyType(char* inputStr, char* type) {
  // this function puts in type the returntype from a function or
  // method, or the type of a parameter or an attribute. The input is
  // a string containing the type info. This might either be a declStr
  // (see description above) or a string with only type info.
  // The output is according to the FAMOOS Information Exchange Model
  // conventions, namely no spaces as long as it not really necessary
  // (example of "really necessary": unsigned int), and const
  // declarations are ignored.

  char input_[256] = ""; // for local copy (needed for strtok!)
  char tmpBuf[256] = ""; // buffer to store the signature
  char* token;
  int noReturnType = 1;
  
  strcpy(input_,inputStr); // make local copy (needed for strtok!)

  token = strtok(input_," ");  // initialize strtok
  
  // check first token
  if (token) {
    if (strstr(token,"@I"))  // "@Istatic@I" -> ignore this token by
      // taking the next one
      token = strtok(NULL," ");
    while (token && !strstr(token,"@B")) {
      
      if (!strcmp(token,"*") || !strcmp(token,"&"))
	strcat(tmpBuf,token);
      else if (strcmp(token,"const")) { // ignore const 
	// not a * or & or const: if not the first part of a
	// type, put a space in between (for f.i. "unsigned int"
	if (!noReturnType) // no leading space
	  strcat(tmpBuf," ");
	strcat(tmpBuf,token);
	noReturnType = 0;
      }
      
      token = strtok(NULL," "); // next token
    }

    // FAMOOS model convention: void appears as empty string
    if (!strcmp(tmpBuf,"void")) strcpy(tmpBuf,"");
  }
  else // empty input
    strcpy(tmpBuf,"");

  
  // finally, copy result in returnType
  strcpy(type,tmpBuf);
}


int createReturntypeFromDeclStr (si_Item* item, char* returnType) {
// Extract returntype information from declStr
// Adapted from the 'retriever.cc' file produced by FZI

  // Uses declStr (see above) 
  // This function parses the declStr using strtok and determines if
  // the returnType is present. If yes, it puts this in the buffer,
  // else "".

  // NOTE: Unfortunately item->take._incl->typeStr contains useless
  // info (namely "MethodDef") instead of the type as it does for
  // parameters (see visitParameters).


  char type_[256]; // buffer to store the signature
  
  // check if declStr contains @B, see declStr description above.
  if (strstr(item->take._incl->declStr,"@B"))
    modifyType(item->take._incl->declStr,type_);

  else {
    // error in the SNiFF+ declStr: give warning and put empty string as
    // inconsistent, but valid information
    fprintf(stderr,"\nWARNING: empty returntype returned while processing %s!\n", item->name);
    strcpy(type_,"");
    debugMsgStrStrStr(" declStr of item %s = %s\n",item->name,item->take._incl->declStr);
  }
  

  // finally, copy result in returnType
  strcpy(returnType,type_);
}


void createUniqueNameOfAttrOrMethod(si_Item* item, char* name) {

  // creates unique name for methods, functions, attributes and global
  // variables.
  // The unique name is:
  //   [unique_name_of_class.]signature 

  char className[256];
  char signature[256];

  // createClassNameFromDeclStr returns empty string if there is no
  // classname associated with item, i.e. item is global function or
  // variable.
  
  createClassNameFromDeclStr(item, className); 
  createSignature(item, signature);

  // check for empty classname, because then the dot shouldn't appear.
  if (strcmp(className,""))
    sprintf(name,"%s.%s",className,signature);
  else
    strcpy(name,signature);
}



//------- Functions that add some info in the buffer ------------


int addHeader (char* CDIFKeyword,
	       char* buf, int writePos) {
  // Constructs "header" of a CDIF entity, which means an opening
  // parenthesis, the entity type and a CDIF identifier. The CDIF
  // identifier consists of the letters FM and a following integer.
  // Example:
  // (Class FM127
  //
  // Returns the position in the bufferof the last character written. 

  char header[100];

  sprintf (header,"\n(%s FM%d", 
	   CDIFKeyword,
	   computeCDIFIdentifierInt()
	   );
  
  return writePos + sprintf (&buf[writePos], header);
}


int addName (si_Item* item,
	     char* buf, int writePos) {
 // Constructs CDIF name attribute and adds it to buffer.
 // Returns the position in the buffer of the last character written.
 
  return writePos 
    + sprintf (&buf[writePos],
	       "\n\t(name \"%s\")",
	       item->name
	       );
}

int addUniqueNameOfClass (si_Item* item,
	     char* buf, int writePos) {
  // Constructs CDIF unique name attribute for classes and adds it to
  // buffer. The unique name for a class is simply the name. Unique
  // names could consist of the namespace of a class (see ANSI C/C++
  // standard (ISO/IEC 14882 standard for the C++ programming
  // language)), but this information is not provided by the current
  // Sniff+ version (2.4.1).
  //
  // Returns the position in the buffer of the last character written.
 
  char uniqueName[300];
  
  createUniqueNameOfClass(item,uniqueName);

  return writePos 
    + sprintf (&buf[writePos],
	       "\n\t(uniqueName \"%s\")",
	       uniqueName
	       );
}


int addUniqueNameOfMethodOrAttr (si_Item* item,
	     char* buf, int writePos) {
  // Constructs CDIF unique name attribute for methods and adds it to
  // buffer. The unique name for a method is:
  //   uniquenameOfClass + "." + method signature 
  //
  // Returns the position in the buffer of the last character written.
 
  char uniqueName[300];


  createUniqueNameOfAttrOrMethod(item,uniqueName);

  return writePos 
    + sprintf (&buf[writePos],
	       "\n\t(uniqueName \"%s\")",
	       uniqueName
	       );
}

int addUniqueNameOfParameter (si_Item* theParameter, si_Item* theMethod,
	     char* buf, int writePos) {
  // Constructs CDIF unique name attribute for parameters and adds it to
  // buffer. The unique name for a formal parameter is:
  //   uniquenameOfMethod + "." + formal parameter name
  //
  // Returns the position in the buffer of the last character written.
 
  char uniqueNameOfMethod[300];

  createUniqueNameOfAttrOrMethod(theMethod,uniqueNameOfMethod);

  return writePos 
    + sprintf (&buf[writePos],
	       "\n\t(uniqueName \"%s.%s\")",
	       uniqueNameOfMethod,
	       theParameter->name
	       );
}


int addSourceAnchor (si_Item* item,
		     char* fileName, 
		     char* buf, int writePos) {
  // Constructs CDIF sourceAnchor attribute and adds it to buffer. The
  // source anchor in this case is the name of the source code file,
  // followed by the character start position and character end
  // position of the item definition. Sniff+ provides this
  // information. The sourceAnchor value is delimited by a "|" in the
  // TextValue.
  //
  // Returns the position in the buffer of the last character written.
 
  char srcAnchorAttr[300];

  if(showSrcAnchor) {
    sprintf (srcAnchorAttr,
	     "\n\t(sourceAnchor #[file \"%s\" start %d end %d|]#)",
	     fileName,
	     item->take._incl->sPos,
	     item->take._incl->ePos
	     );
    
    return writePos + sprintf (&buf[writePos], srcAnchorAttr);
  }
  else return writePos;
}


addBelongsToClass(si_Item* theClass,
		  char* buf, int writePos) {

  // adds belongsToClass attribute with as value the uniqueName of
  // theClass to buf.
  // PRE: theClass is of type eTClass
  // Returns the position in the buffer of the last character written.

  char uniqueNameOfClass[300];

  createUniqueNameOfClass(theClass,uniqueNameOfClass);

  return writePos 
    + sprintf (&buf[writePos], 
	       "\n\t(belongsToClass \"%s\")",
	       uniqueNameOfClass
	       );
}


int addHasClassScope(si_Item* item, char* buf, int writePos) {
  // Returns the position in the buffer of the last character written.

  return writePos 
    + sprintf (&buf[writePos],
	       "\n\t(hasClassScope %s)",
	       (isStatic (item))?"-TRUE-":"-FALSE-"
	       );
}


int addAccessControlQualifier(si_Item* item, char* buf, int writePos) {
  // Returns the position in the buffer of the last character written.

  return writePos 
    + sprintf (&buf[writePos],
	       "\n\t(accessControlQualifier %s)",
	       accessControlQualifier(item)
	       );
}


int addIsAbstract(si_Item* item, char* buf, int writePos) {
  // Returns the position in the buffer of the last character written.

  return writePos 
    + sprintf (&buf[writePos],
	       "\n\t(isAbstract %s)",
	       (isAbstract (item))?"-TRUE-":"-FALSE-"
	       );
}


int addIsConstructor(si_Item* item, si_Item* parent, char* buf, int writePos) {
  // in C++ and Java, a constructor is a method which has the same
  // name as the class it is defined in.
  // Returns the position in the buffer of the last character written.

  return writePos 
    + sprintf (&buf[writePos],
	       "\n\t(isConstructor %s)",
	       ((parent->type == eTClass) && !strcmp(item->name, parent->name))?"-TRUE-":"-FALSE-"
	       );
}


int addAttrWithMethodOrAttr(char* cdifAttrName, si_Item* item, 
			    char* buf, int writePos) {
  // adds attr with name attrName and value the uniqueName of item
  // (which should be a method or an attribute).
  // uniqueName = className::Signature
  // Returns the position in the buffer of the last character written.

  char uniqueName[300];

  createUniqueNameOfAttrOrMethod(item,uniqueName);

  return writePos + sprintf (&buf[writePos],
			     "\n\t(%s \"%s\")",
			     cdifAttrName,
			     uniqueName
			     );
}


int addSignature (char* cdifAttrName, si_Item* item, char* buf, int writePos) {
  // Returns the position in the buffer of the last character written.

  char signature[300];

  createSignature(item,signature);

  return writePos + sprintf (&buf[writePos],
			     "\n\t(%s \"%s\")",
			     cdifAttrName,
			     signature
			     );
}


int addBase (si_Item* item, char* buf, int writePos) {
  // Returns the position in the buffer of the last character written.

  char baseName[300]; // name of base of invocation

  createClassNameFromDeclStr(item, baseName);

  return writePos + sprintf (&buf[writePos],
			     "\n\t(base \"%s\")",
			     baseName
			     );

}


int addReturntype (si_Item* item, char* buf, int writePos) {
  // adds returnType from attribute, method, function or global
  // variable to buf.
  // Returns the position in the buffer of the last character written.

  // NOTE: Unfortunately item->take._incl->typeStr contains useless
  // info (namely "MethodDef") instead of the type as it does for
  // parameters (see visitParameters).

  char returnType[256];

  createReturntypeFromDeclStr(item,returnType);

  // *** put result in buffer

  return writePos + sprintf (&buf[writePos],
			     "\n\t(declaredReturnType \"%s\")",
			     returnType
			     );
}


int addClosing (char* buf, int writePos) {
  // adds closing parenthesis (= CDIF CloseScope) 
  return writePos + sprintf (&buf[writePos],
			     "\n)\n"
			     );
}


//------------------ Visitor procedures --------------------


//debugTokenStr is declared somewhere else. It maps
//the si_Type enumeration type on the corresponding string
extern char* debugTokenStr [];


void  visitSuperclasses(si_Item* current, 
		 HandbackSniffEntitySpec handBack,
		 int maxAuxBuf, char* auxBuf)
     // Visits superclasses of current. Used to compute the FAMOOS
     // InheritanceDefinition (in CDIF format).
     //
     // Uses the si_Collection si_Item->take_.incl->superClass, which
     // contains a list of si_Items in pairs of two, where the first
     // is the inheritance visibility (type eTScope) and the second
     // the superclass itself (type eTClass).
     // SNiFF+ query eQOOGetSuper could be used instead.
     //
     // NOTE: It is not clear if superclasses that are no part of the 
     //       parsed project are found in this way.
     

{
  int lastAuxBuf;
  si_Collection* superclasses;
  si_Item* item;
  si_Item* nextItem;
  char visibility[10];
  int index = 0; // number of superclasses

  char uniqueNameOfSubclass[300];
  char uniqueNameOfSuperclass[300];

  createUniqueNameOfClass(current,uniqueNameOfSubclass);
  strcpy(visibility,"-NULL-"); // default

  // note: could (should) use official query to be immune for
  // implementation details.

  superclasses = current->take._incl->superClass;
  
  if (superclasses != NULL) {
    item = superclasses->first;
    while (item != NULL) {
      nextItem = item->next;   // save next because getHashed() might destroy it !!!


      if (checkHashed(&item)) {

	

	if (item->type==eTScope) {// item contains inheritance visibility 
	  // inheritance visibility appears to be always undef (since
	  // Sniff 3.0.1. Bugreport sent.
	  // fprintf(stderr,"inheritance visibility = %s\n", item->name);
	  strcpy(visibility,item->name);
	}	
	else if (item->type==eTClass) { // item contains superclass
	  index++; 
	  
	  createUniqueNameOfClass(item,uniqueNameOfSuperclass);
	  
	  // From version 3.0 on the superclass name stored in the
	  // Symbol Table is "*" (apparently, because undocumented) if
	  // the class or struct doesn't have a superclass. That's why
	  // we filter those cases out here.
	  
	  if (strcmp(uniqueNameOfSuperclass, "*")) {
	    
	    // create CDIF InheritanceDefinition for every superclass
	    lastAuxBuf = 0; //reset buffer	
	    lastAuxBuf = addHeader("InheritanceDefinition", auxBuf, lastAuxBuf);
	    
	    lastAuxBuf = lastAuxBuf 
	      + sprintf (&auxBuf[lastAuxBuf],
			 "\n\t(subclass \"%s\")\n\t(superclass \"%s\")",
			 uniqueNameOfSubclass,
			 uniqueNameOfSuperclass
			 );
	    
	    if (showFullInheritanceDef) {
	      // the function addAccessControlQualifier can NOT be used
	      // here, because the completely different way the access
	      // control qualifier is determined for inheritance
	      // definitions, namely by a separate si_Item with type
	      // eTScope. 
	      // index is always null for C++ and Java (see the
	      // respective language plug-ins).
	      lastAuxBuf = lastAuxBuf 
		+ sprintf (&auxBuf[lastAuxBuf],
			   "\n\t(accessControlQualifier \"%s\")\n\t(index -NULL-)",
			   visibility
			   );
	    }	
	    
	    lastAuxBuf = addClosing(auxBuf, lastAuxBuf);
	    
	    handBackAuxBuf (handBack, maxAuxBuf, auxBuf, lastAuxBuf);
	  }
	  //else fprintf(stderr,"skipped superclass with name *\n");
	}	
      }
      item = nextItem;
    }
  }
}


void visitClass (si_Item* current,
		 char * fileName,
		 HandbackSniffEntitySpec handBack,
		 int maxAuxBuf, char* auxBuf)
// called when visiting a class while enumerating the symboltable.
// Use auxBuf as the buffer to write the information that is to be handed back
// pre: current not hashed


{ 
  // *** handle class (level 1) *** 

  int lastAuxBuf = 0;
  
  lastAuxBuf = addHeader("Class", auxBuf, lastAuxBuf);

  lastAuxBuf = addName(current, auxBuf, lastAuxBuf);

  lastAuxBuf = addUniqueNameOfClass(current, auxBuf, lastAuxBuf);

  lastAuxBuf = addIsAbstract (current,
			      auxBuf, lastAuxBuf); 

  lastAuxBuf = addSourceAnchor(current, fileName,
				   auxBuf, lastAuxBuf);
  
  lastAuxBuf = addClosing(auxBuf, lastAuxBuf);
  
  handBackAuxBuf (handBack, maxAuxBuf, auxBuf, lastAuxBuf);

  // *** handle superclasses (level 1) ***

  visitSuperclasses(current, handBack, maxAuxBuf, auxBuf);

}


void visitParameters (si_Item* theMethod,
		      si_Collection * theParams,
		      HandbackSniffEntitySpec handBack,
		      int maxAuxBuf, char* auxBuf)
// visit all parameters in theParams; return last position written
// Use auxBuf as the buffer to write the information that is to be handed back
// pre: lastAuxBuf is the last position written
// post: function result is the last position written

     // theParams consists of a si_Collection of parameters (eTParam)
     // of theMethod. Some items are "()", which is a Sniff thing and
     // can be ignored. The rest are the real parameters of the
     // method. 

     // NOTE: formal parameters may have no name! (which breaks the
     // uniqueness criterium of names in the FAMOOS model). Formal
     // parameters are still unique because they have different
     // positions in the method signature

{
  si_Item * current, * nextItem;
  int lastAuxBuf;
  si_Type itemType;
  int paramPosition = 0;
  char modifiedType[256];
  
  if (theParams != NULL) {
    current = theParams->first;
    while(current) {
      nextItem = current->next;
      // first check the Sniff special thing "()".
      // (strcmp(current->name, "()") returns 0 if the strings are
      // equal (!).
      if (strcmp(current->name, "()")) {
	itemType = current->type;
	
	if (checkHashed(&current)) {
	  
	  if (current->type==eTParam) { // type check possibly unnecessary

	    paramPosition++;
	    
	    // create FormalParameterDefinition
	    lastAuxBuf = 0; // reset buffer
	    lastAuxBuf = addHeader("FormalParameter", auxBuf, lastAuxBuf);
	    
	    lastAuxBuf = addName(current, auxBuf, lastAuxBuf);
	    
	    // NOTE: current->take._incl->typeStr seems to be null
	    // sometimes. Probably only in the special Sniff "()"
	    // case, so this couldn't happen here. Check to be sure.
	    
	    if (current->take._incl->typeStr) {
	      // modify type into FAMOOS conventions
	      modifyType(current->take._incl->typeStr,modifiedType);
	      // add result to buffer
	      lastAuxBuf = lastAuxBuf + 
		sprintf (&auxBuf[lastAuxBuf],
			 "\n\t(declaredType \"%s\")",
			 modifiedType
			 );
	    }

	    lastAuxBuf = addAttrWithMethodOrAttr("belongsTo", 
						 theMethod, auxBuf, lastAuxBuf);

	    lastAuxBuf =
	      addUniqueNameOfParameter(current,theMethod,auxBuf, lastAuxBuf);

	    lastAuxBuf = lastAuxBuf + 
	      sprintf (&auxBuf[lastAuxBuf],
		       "\n\t(position %d)",
		       paramPosition
		       );
    
	    lastAuxBuf = addClosing(auxBuf, lastAuxBuf);
	    
	    handBackAuxBuf (handBack, maxAuxBuf, auxBuf, lastAuxBuf);
	    
	  }
	  // ** for test purposes **
	  else { // would happen if method subitem is not an eTParam
	    fprintf(stderr,"  wrong type: should be eTParam!\n");
	  }
	}
      }
      current = nextItem;
    }
  }  
}


void visitMethod (si_Item* theMethod, 
		  char* fileName, si_Item* parent, 
		  HandbackSniffEntitySpec handBack,
		  int maxAuxBuf, char* auxBuf)
// Called when visiting a Method definition. 
// Use auxBuf as the buffer to write the information that is to be handed back

{ // **** handle method (level 1) ****

  int lastAuxBuf = 0;

  lastAuxBuf = addHeader("Method", auxBuf, lastAuxBuf);

  lastAuxBuf = addName(theMethod, auxBuf, lastAuxBuf);

  lastAuxBuf = addBelongsToClass(parent,
				 auxBuf, lastAuxBuf);

  lastAuxBuf = addUniqueNameOfMethodOrAttr(theMethod, auxBuf, lastAuxBuf);

  lastAuxBuf = addSourceAnchor(theMethod, fileName,
				   auxBuf, lastAuxBuf);

  lastAuxBuf = addAccessControlQualifier(theMethod,
					 auxBuf, lastAuxBuf);

  lastAuxBuf = addHasClassScope (theMethod,
				 auxBuf, lastAuxBuf);

  lastAuxBuf = addSignature ("signature", theMethod,
			     auxBuf, lastAuxBuf);

  lastAuxBuf = addIsAbstract (theMethod,
			      auxBuf, lastAuxBuf); 

  lastAuxBuf = addIsConstructor (theMethod, parent,
			      auxBuf, lastAuxBuf); 


  lastAuxBuf = addReturntype (theMethod, auxBuf, lastAuxBuf);

  // TODO: add returnclass

  lastAuxBuf = addClosing(auxBuf, lastAuxBuf);
  
  handBackAuxBuf (handBack, maxAuxBuf, auxBuf, lastAuxBuf);

  // **** handle parameters ****

  // this is now done via case eTMethodI in enumerateItemParts!!

  //visitParameters (theMethod, theMethod->take._incl->subItems,
  //		   handBack, maxAuxBuf, auxBuf); 


}

void visitFunction (si_Item* theFunction, 
		  char* fileName, si_Item* parent, 
		  HandbackSniffEntitySpec handBack,
		  int maxAuxBuf, char* auxBuf)
// Called when visiting a Method definition. 
// Use auxBuf as the buffer to write the information that is to be handed back

{ // **** handle method (level 1) ****

  int lastAuxBuf = 0;

  lastAuxBuf = addHeader("Function", auxBuf, lastAuxBuf);

  lastAuxBuf = addName(theFunction, auxBuf, lastAuxBuf);

  lastAuxBuf = addUniqueNameOfMethodOrAttr(theFunction, auxBuf, lastAuxBuf);

  lastAuxBuf = addSourceAnchor(theFunction, fileName,
				   auxBuf, lastAuxBuf);

  lastAuxBuf = addSignature ("signature", theFunction,
			     auxBuf, lastAuxBuf);

  lastAuxBuf = addReturntype (theFunction, auxBuf, lastAuxBuf);

  lastAuxBuf = addClosing(auxBuf, lastAuxBuf);
  
  handBackAuxBuf (handBack, maxAuxBuf, auxBuf, lastAuxBuf);

  // **** handle parameters ****

  // this is now done via case eTMethodI in enumerateItemParts!!

  //visitParameters (theMethod, theMethod->take._incl->subItems,
  //		   handBack, maxAuxBuf, auxBuf); 


}

void visitAccess (si_Item* theAttribute,
			  si_Item* referredBy,
			  HandbackSniffEntitySpec handBack,
			  int maxAuxBuf, char* auxBuf)
// Called when visiting an Attribute referred by something else. Use
// auxBuf as the buffer to write the information that is to be
// handed back.
//
// PRE: si_Items not hashed.

{
  int lastAuxBuf = 0;
  char* parentName;
  si_Item* from;
  
  lastAuxBuf = addHeader("Access", auxBuf, lastAuxBuf);
 
  lastAuxBuf = addAttrWithMethodOrAttr("accesses",
				       theAttribute, auxBuf, lastAuxBuf);

  lastAuxBuf = addAttrWithMethodOrAttr("accessedIn", 
					   referredBy, auxBuf, lastAuxBuf);
    
  lastAuxBuf = addClosing(auxBuf, lastAuxBuf);

  handBackAuxBuf (handBack, maxAuxBuf, auxBuf, lastAuxBuf);
}


void visitAttribute (si_Item* theAttribute, char* fileName, si_Item* parent,
		     HandbackSniffEntitySpec handBack,
		     int maxAuxBuf, char* auxBuf)
// Called when visiting a Attribute definition. 
// Use auxBuf as the buffer to write the information that is to be handed back.
     
{ 
  int lastAuxBuf = 0;

  if (checkHashed(&theAttribute)) {

    // **** handle attribute (level 2) ****

    lastAuxBuf = addHeader("Attribute", auxBuf, lastAuxBuf);

    lastAuxBuf = addName(theAttribute, auxBuf, lastAuxBuf);

    lastAuxBuf = addBelongsToClass(parent,
				   auxBuf, lastAuxBuf);

    lastAuxBuf = addUniqueNameOfMethodOrAttr(theAttribute, auxBuf, lastAuxBuf);

    lastAuxBuf = addSourceAnchor(theAttribute, fileName,
				   auxBuf, lastAuxBuf);

    lastAuxBuf = addHasClassScope (theAttribute,
				   auxBuf, lastAuxBuf);

    lastAuxBuf = lastAuxBuf + 
      sprintf (&auxBuf[lastAuxBuf],
	       "\n\t(declaredType \"%s\")",
	       theAttribute->take._incl->typeStr
	       );

    lastAuxBuf = addAccessControlQualifier(theAttribute,
					 auxBuf, lastAuxBuf);
    
    lastAuxBuf = addClosing(auxBuf, lastAuxBuf);
    
    handBackAuxBuf (handBack, maxAuxBuf, auxBuf, lastAuxBuf);
  }
}


void visitGlobalVariable (si_Item* theAttribute, char* fileName, si_Item* parent,
		         HandbackSniffEntitySpec handBack,
		         int maxAuxBuf, char* auxBuf)
// Called when visiting a GlobalVariable definition. 
// Use auxBuf as the buffer to write the information that is to be handed back.

{ 
  int lastAuxBuf = 0;

  if (checkHashed(&theAttribute)) {

    // **** handle attribute (level 2) ****

    lastAuxBuf = addHeader("GlobalVariable", auxBuf, lastAuxBuf);

    lastAuxBuf = addName(theAttribute, auxBuf, lastAuxBuf);

    lastAuxBuf = addUniqueNameOfMethodOrAttr(theAttribute, auxBuf, lastAuxBuf);

    lastAuxBuf = addSourceAnchor(theAttribute, fileName,
				   auxBuf, lastAuxBuf);


    lastAuxBuf = lastAuxBuf + 
      sprintf (&auxBuf[lastAuxBuf],
	       "\n\t(declaredType \"%s\")",
	       theAttribute->take._incl->typeStr
	       );

    lastAuxBuf = addClosing(auxBuf, lastAuxBuf);
    
    handBackAuxBuf (handBack, maxAuxBuf, auxBuf, lastAuxBuf);
  }
}


void visitInvocation (si_Item* invokingMethod,
			  si_Item* invokedMethod,
			  HandbackSniffEntitySpec handBack,
			  int maxAuxBuf, char* auxBuf)
// Called when visiting a Method referring to something else
// Use auxBuf as the buffer to write the information that is to be
// handed back

{
  int lastAuxBuf = 0;

  lastAuxBuf = addHeader("Invocation", auxBuf, lastAuxBuf);
  
  lastAuxBuf = addAttrWithMethodOrAttr("invokedBy", 
				       invokingMethod,auxBuf,lastAuxBuf);

  lastAuxBuf = addSignature("invokes", 
			    invokedMethod,auxBuf,lastAuxBuf);

  lastAuxBuf = addBase(invokedMethod,auxBuf,lastAuxBuf);

  lastAuxBuf = addClosing(auxBuf, lastAuxBuf);
  
  handBackAuxBuf (handBack, maxAuxBuf, auxBuf, lastAuxBuf);
}


//------------------ Enumerator auxiliary procedures --------------------


void enumerateMethodReferences ( si_Item* theMethod,
			  HandbackSniffEntitySpec handBack,
			  int maxAuxBuf, char* auxBuf)
  // note: theMethod should be eTMethodI !!
  // pre: level>=3
{
  si_Collection * methodRefs;
  si_Item * current, * nextItem;
  si_Type itemType;
  char* itemName;

  // Query returns all si_Item's an eTMethodI references to. Items can
  // be classes, methods (eTMethodI), variables and "undefined"
  // (eTUndef) items.
  methodRefs = si_Query( eQReferencesTo, eSGlobal, theMethod);

  if (methodRefs) {

    /**
    // bug in Swing project: methodRefs are always null
    fprintf(stderr, "in if\n");
    if (methodRefs->first) 
      fprintf(stderr, " first is not null.\n"); 
	else
      fprintf(stderr, " first is null.\n"); 
    **/
    
    for (current = methodRefs->first; current != NULL; current = nextItem) {
      
      nextItem = current->next;
      itemType = current->type;
      itemName = current->name;
      
      if (checkHashed(&current)) {
		switch (itemType) {
		  case eTMethodI:
			if (showMethInvoc)
			visitInvocation(theMethod, current, handBack, maxAuxBuf, auxBuf);
			break;
		  case eTVar:
			if (showVarAccess)
			  visitAccess (current, theMethod, handBack, maxAuxBuf, auxBuf);
			break;
		  case eTConst:
			//fprintf(stderr, "const %s is referenced in %s\n", itemName, theMethod->name);
			if (showVarAccess)
			  visitAccess (current, theMethod, handBack, maxAuxBuf, auxBuf);
			break;
		  default:

//	Classes, ....
//  eTUndefs (probably) denotes everything which is not defined within the project


	  //fprintf(stderr, "item %s is referenced in %s\n", itemName, theMethod->name);
	  //if (itemType == eTUndef) fprintf(stderr, "type is eTUndef\n");
		}
	

      }
      else //set current to something else to avoid termination of loop
		current = nextItem; 
	}
  }
  else fprintf(stderr, "\nWARNING: no methodrefs!\n");
}


void enumerateItemParts (SNiFFACCESS slot,
			 char * fileName,
			 si_Item* parent,
			 si_Collection* subParts,
			 HandbackSniffEntitySpec handBack,
			 int maxAuxBuf, char* auxBuf)
     // mainly recursive version of enumerateFileParts. Every item
     // that comes is is handled and then recursively its subparts.

{

  char tmpString[256];


  si_Item *current, *nextItem;
  si_Type itemType;
  char* itemName;

  char testTypeName[15]; // for debugging

   if (subParts != NULL) {

    for (current = subParts->first; current != NULL; current = nextItem) {

      nextItem = current->next;
      itemType = current->type;
      itemName = current->name;

      debugMsgStrStr(" name of item = %s\n",itemName);

      if (checkHashed(&current)) {

	switch (itemType) {
	  case eTClass:
      debugMsgStr(" type of item = eTClass\n");
	    strcpy(testTypeName, "eTClass");

	     if (current->take._incl->declStr) {
	       uniqueNameOfClass(current, tmpString);
	     }
	     

	    visitClass (current, fileName, handBack, maxAuxBuf, auxBuf);
	    break;
	  case eTMethodD:
      debugMsgStr(" type of item = eTMethodD\n");
	    strcpy(testTypeName, "eTMethodD");
	    visitMethod (current, fileName, parent, handBack, maxAuxBuf, auxBuf);
	    break;
	  case eTMethodI:
      debugMsgStr(" type of item = eTMethodI\n");
	    strcpy(testTypeName, "eTMethodI");
	    if (parent->type==eTClass) { // ensuring that eTMethodI is only
	                                 // handled once, because some also
	                                 // appear as subpart of eTFile
	      if (level>=3 && (showVarAccess || showMethInvoc))
		enumerateMethodReferences(current,handBack,maxAuxBuf,auxBuf);
	    
	      if (level>=4)
		// as far as I know, the parameters can be retrieved via
		// eTMethodD as well.
		visitParameters (current, current->take._incl->subItems,
				 handBack, maxAuxBuf, auxBuf);
	      }
	    break;
	  case eTProc:
      debugMsgStr(" type of item = eTProc\n");
	    strcpy(testTypeName, "eTProc");
	    visitFunction (current, fileName, parent, handBack, maxAuxBuf, auxBuf);

	    if (level>=3 && (showVarAccess || showMethInvoc))
	      enumerateMethodReferences(current,handBack,maxAuxBuf,auxBuf);
	    
	    if (level>=4)
	      visitParameters (current, current->take._incl->subItems,
			       handBack, maxAuxBuf, auxBuf);
	    break;
	  case eTVar:
      debugMsgStr(" type of item = eTVar\n");
	    strcpy(testTypeName, "eTVar");
	    if (level>=2)
	      if (parent->type==eTFile) // global scope -> global variable
		visitGlobalVariable (current, fileName, parent, handBack, maxAuxBuf, auxBuf);
	      else if (parent->type==eTClass) // class scope -> attribute
		visitAttribute (current, fileName, parent, handBack,
				maxAuxBuf, auxBuf);
	      else 
		fprintf(stderr, "OTHER KIND OF VARIABLE OCCURRED!");
	    break;
	  case eTMacro:
	    strcpy(testTypeName, "eTMacro");
	    // ignored
	    break;
	  case eTTypedef:
	    strcpy(testTypeName, "eTTypedef");
	    // ignored
	    break;
	  case eTEnum:
	    strcpy(testTypeName, "eTEnum");
	    break;
	    // ignored
	  case eTComment:
	    strcpy(testTypeName, "eTComment");
	    // In my experience si_Items of type eTComment contain not
	    // much useful information:
	    //  name is " "
	    //  take._incl->typeStr = NULL
	    //  take._incl->declStr = NULL
	    // only take._incl->sPos and ePos contain their usual info.
	    // So we further ignore this item.
	    break;
	  case eTConst:
		// After a little test it seems that  SNiFF+ hanldles global const variables
		// as eTConsts and local const variables as local variables. Therefore the
		// "else if" clause should be unnecessary.
	    strcpy(testTypeName, "eTConst");
	    if (level>=2)
	      if (parent->type==eTFile) // global scope -> global const
		visitGlobalVariable (current, fileName, parent, handBack, maxAuxBuf, auxBuf);
	      else if (parent->type==eTClass) // class scope -> attribute
		visitAttribute (current, fileName, parent, handBack,
				maxAuxBuf, auxBuf);
	      else 
		fprintf(stderr, "OTHER KIND OF CONST OCCURRED!");
	    break;
	  case eTIncl:
	    strcpy(testTypeName, "eTIncl");
	    // ignored
	    break;
	  case eTParam:
	    strcpy(testTypeName, "eTParam");
	    // ignored
	    break;
	  default:
	    strcpy(testTypeName, "default");
	    // ignored
	    break;
	  };
	  
	  debugMsgStrStrStr("--item \"%s\" with type %s processed\n", current->name, testTypeName);
	  //fprintf(stderr,"--item \"%s\" with type %s processed\n", current->name, testTypeName);
	
	  // recursive call with sub-items of current
	  enumerateItemParts (slot,
			      fileName,
			      current,
			      current->take._incl->subItems,
			      handBack, maxAuxBuf, auxBuf
			      );      
      }
    }
   }	
}




//------------------ Enumerator main entry procedures --------------------


void enumerateSymbolTableUsingImplementationFiles (SNiFFACCESS slot,
			   char * projectFile,
			   HandbackSniffEntitySpec handBack)
  // Enumerate all files in the project, and for each file visit all
  // subitems (classes, global functions, etc.).
  // This assures that classes are only visited once during this
  // enumeration. 
{
  si_Collection* coll;
  si_Item* current;
  si_Item* nextItem;
  char auxBuf[2000];
  int maxAuxBuf = 1000;

  // needed to ignore double files; bug in sniff 3.0.1, announced to be fixed in 3.1
  char firstFileName[1000];
  int passedFirstFileName = FALSE;
 
  debugMsgStr("--si_Query (implementation files) \n");
  coll = si_Query (eQImplFiles, eSGlobal, NO_ITEM);
  
  if (coll != NULL) {
    debugMsgStr("--eQImplFiles succeeded...\n");

    if (showCDIFHeader)
      printMinimalCDIFHeader(projectFile, coll->first, handBack, maxAuxBuf, auxBuf);

    current = coll->first;

    while (current != NULL) {
      nextItem = current->next;
      if (checkHashed(&current)) {

	debugMsgStrStr("\nFILE %s:\n",current->name);
	
	// hack to ignore double files; bug in sniff 3.0.1, announced to be fixed in 3.1
	// NOTE: current->take._incl->declStr contains full filename contrary to what
	//       is said in the Symbol Table API documentation!
	if (!passedFirstFileName) {
	  strcpy(firstFileName,current->take._incl->declStr);
	  passedFirstFileName = TRUE;
	}
	else
	  if (!strcmp(firstFileName,current->take._incl->declStr) )
	    // file already processed, break out of while loop 
	    break;	  
	
	enumerateItemParts (slot,
			    current->name,
			    current,
			    current->take._incl->subItems,
			    handBack, maxAuxBuf, auxBuf);
      }
      current = nextItem;
    }
    
    if (showCDIFHeader)
      printClosingCDIFTransfer(handBack, maxAuxBuf, auxBuf);
    
  }
  else
    debugMsgStr("--eQImplFiles returns NULL!! (i.e. no files)\n");

}

void enumerateSymbolTable (SNiFFACCESS slot,
			   char * projectFile,
			   HandbackSniffEntitySpec handBack)
  //Enumerate the files in the project to visit all classes exactly once
  //Then for each class enumerate all subparts to visit all methods and attributes
{
  debugMsgStrStr("--si_open_project (%s) \n", projectFile);

  fprintf(stderr,"Opening %s...\n",projectFile);
  if (si_open_project (slot, projectFile)) {
    debugMsgStrStr("--si_open_project (%s) succeeded!\n", projectFile);

    //Enumerate file parts so that each class is only visited once
    fprintf(stderr,"Processing SNiFF+ symboltable...\n");
    enumerateSymbolTableUsingImplementationFiles (slot, projectFile, handBack);
    fprintf(stderr,"\n"); // to end the line with progress dots
  }
  else
	fprintf(stderr,"Error: Unable to open %s...\n",projectFile);
  debugMsgStrStr("--si_close_project (%s) \n", projectFile);
  fprintf(stderr,"Closing %s...\n",projectFile);
  si_close_project (slot, projectFile);
}




/*-----------------------------------------------------

Here follow the implementations of the procedures declared in the
header files.

------------------------------------------------------*/

void sniffAPIisAvailable ( void )
 {}

int readSniffSymbolTable (char * projectFile,
			  HandbackSniffEntitySpec handBack,
			  TerminatedReading terminatedReading)
{
  SNiFFACCESS slot;  // the access slot for further calls

  debugMsgStrStr("--readSniffSymbolTable (%s) \n", projectFile);

  __si__module__init ();  // initialize Symbol Table API;

  fprintf(stderr,"Connecting to SNiFF+...\n");
  slot = si_open ("session0",NULL);  // connect to Sniff;

  enumerateSymbolTable (slot, projectFile, handBack);

  fprintf(stderr,"Closing connection to SNiFF+...\n");
  si_exit (slot);  // disconnect from Sniff;
  terminatedReading ();
  return 0;
}

