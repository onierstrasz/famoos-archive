/*
 * This file is part of sniff2famix
 * Copyright (C) 1999  Sander Tichelaar, tichel@iam.unibe.ch
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
 * USA.
 */ 

/************************************************************************
 * File: extractor.h
 * 
 * Description:
 *
 * Version history:
 *   28.06.97: First version based on a previous version that tried
 *     an immediate access of the SNiFF_API by Serge Demeyer.
 *   18.07.97: Second version -- added finishing callback
 *   07.05.98: Version 0.9 frozen by Sander Tichelaar, tichel@iam.unibe.ch
 *   13.08.98: Version 1.0 frozen
 *   14.06.99: Version 1.1 frozen, renamed to sniff2famix, added GNU
 *             licence stuff.
 *
 ************************************************************************/


/*-----------------------------

This is an empty procedure which can be called from outside.  Purpose:
check whether the other routines in the library are available.

*/

void sniffAPIisAvailable ( void );

/* accessor methods to set level of reification of the FAMOOS
   model. Default is 1.
*/

void setLevel(int lvl);
int getLevel();

/* toggle for option to show or hide the Access items in the
   output. Default = show.
*/
void showAccess();
void hideAccess();

/* toggle for option to show or hide the Invocation items in the
   output. Default = show.
*/
void showInvocation();
void hideInvocation();

/* toggle for option to show or hide the source anchor in the
   output. Default = show.
*/
void showSourceAnchor();
void hideSourceAnchor();

/* toggle for option to show or hide the attributes
   accessControlQualifier and index. Default = false (because in many
   languages it is useless information).
*/
void showFullInheritanceDefinition();
void hideFullInheritanceDefinition();

/*-----------------------------

typedef for function that determines what to do with the output string
buffers. 

*/
typedef void (*HandbackSniffEntitySpec) (char *);

/*-----------------------------

typedef for a function that announces the end of reading the
symboltable of a SNiFF+ project.

*/
typedef void (*TerminatedReading) ();


/*-----------------------------

This function actually reads the SNiFF-API.  It creates an
entitySpecifier (= a String) for each entity in the SNiFF symboltable
and hands this string over (via the call-back function) to the caller.  

After the last entity is handed back, the 'terminated' procedure is
called. This is to allow calling the reading of the symboltable
in a separate thread -- the terminated procedure can signal the
appropriate semaphores.

*/
int readSniffSymbolTable (char * proj,
			  HandbackSniffEntitySpec handBack,
			  TerminatedReading terminatedReading);

