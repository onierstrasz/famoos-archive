/*
 * This file is part of sniff2famix
 * Copyright (C) 1999  Sander Tichelaar, tichel@iam.unibe.ch
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
 * USA.
 */ 

/************************************************************************
 * File: sniff2famix.c
 * 
 * Description: Creates the FAMIX in CDIF format of a Sniff+
 *              project. Output is dumped on stdout by default. 
 *
 *              For more information about the FAMOOS model and the
 *              CDIF format, see  
 *                http://www.iam.unibe.ch/~famoos/InfoExchFormat/
 *
 * Version history:
 *   07.05.98: First version, version 0.9 frozen by Sander Tichelaar,
 *             tichel@iam.unibe.ch. It is based on testsniffint.c 
 *             from Serge Demeyer.
 *   28.07.98: changed options variableAccess to access and
 *             methodInvocation to invocation.
 *   13.08.98: version 1.0 frozen
 *
 *   06.04.99: added options to set publisher name and to toggle
 *             header on or off.
 *   14.06.99: Version 1.1 frozen, renamed to sniff2famix, added GNU
 *             licence stuff.
 * 
 ************************************************************************/

/*--includes necessary for Linking with SNiFF API--*/
#include "extractor.h"
/*--includes necessary for manipulating stdout, stderr --*/
#include <stdio.h>
/*--includes necessary for converting string to integer --*/
#include <stdlib.h>
/*--includes necessary for strcat --*/
#include <string.h>

FILE* output; // file to write CDIF format in

void mainOutput (char* str) {
  fprintf(stderr, ".");
  fprintf(output, "%s", str);
}


void terminated () {
  fprintf(stderr, "sniff2famix: finished\n");
}


void printversion() {
  fprintf(stderr, "sniff2famix version \"1.1\"\n");
}  

void usage() {
  fprintf(stderr,"Usage: sniff2famix [-options] <sniff-project>\n\n");
  fprintf(stderr,"where options include:\n");
  fprintf(stderr,"    -help, -h, -?               print out this message\n");
  fprintf(stderr,"    -version, -v                print out the version of sniff2famix\n");
  fprintf(stderr,"    -noHeader, -nh              don't put CDIF header in output\n");
  fprintf(stderr,"    -level <1-4>                level of reification in the FAMOOS model.\n");
  fprintf(stderr,"                                Default = 1. The higher the level, the more\n");
  fprintf(stderr,"                                information is included.\n");
  fprintf(stderr,"    +/-access                   show or hide variableAccess (only useful when\n"); 
  fprintf(stderr,"                                level>=3. Default = show.\n");
  fprintf(stderr,"    +/-invocation               show or hide methodInvocation (only useful when\n"); 
  fprintf(stderr,"                                level>=3. Default = show.\n");
  fprintf(stderr,"    +/-sourceAnchor             show or hide source anchors for CDIF entities.\n");
  fprintf(stderr,"                                Default = show.\n");
  fprintf(stderr,"    +/-packages                 show or hide package names. Default = false.\n");
  fprintf(stderr,"    +/-fullInheritanceDef       show or hide full InheritanceDefinition. If false,\n");
  fprintf(stderr,"                                the attrs accessControlQualifier and index of\n");
  fprintf(stderr,"                                InheritanceDefinition are suppressed.\n");
  fprintf(stderr,"                                Default = hide.\n");
  fprintf(stderr,"    -publisherName, -pn <name>  set name of publisher.\n");  
  fprintf(stderr,"    -o <filename>               write output to file with name filename.\n");
  fprintf(stderr,"                                Default = stdout.\n");
}


void returnError(char* errorMsg) { 
  fprintf(stderr,"sniff2famix error: %s\n\n",errorMsg);
  usage(); 
  exit(0);
}

int main(argc, argv)
	int argc;
	char* argv[];
{
  char* projName;
  char* outputFileName;
  int i;
  int error = 0;
  int projNameSet = 0;
  int level;

  // *** initialize ***

  output = stdout;

  // *** end initialize ***

  if (argc>1) // parameters are given
    for(i=1; i<argc;i++) {

      if ( (!strcmp(argv[i],"-help")) || (!strcmp(argv[i],"-h")) ||
					(!strcmp(argv[i],"-?"))) { 
	usage(); exit(0); 
      }

      else if ( (!strcmp(argv[i],"-version")) || (!strcmp(argv[i],"-v"))) { 
	printversion(); exit(0);
      }

      else if (!strcmp(argv[i],"-level"))
	// int should be there as next parameter; read it if available;
	if (argc > (i+1)) { // a next parameter is available
	  level = atoi(argv[++i]); // returns 0 if parameter is not a string
	  if (level>=1 && level<=6)
	    setLevel(level);
	  else returnError("level should be in range of 1-6!");
	}
	else returnError("level should be followed by integer in range of 1-6!");

      else if ( (!strcmp(argv[i],"-publisherName")) || (!strcmp(argv[i],"-pn"))) { 
	// name should be there as next parameter; read it if available;
	if (argc > (i+1)) { // a next parameter is available
	  i++;
	  // check if next parameter is NOT a new option	  
	  if ( (argv[i][0]=='+') || (argv[i][0]=='-')) 
	    returnError("name of publisher missing!");
	  setPublisherName(argv[i]);
	}
	else returnError("name of publisher missing!");
      }
    
      else if (strstr(argv[i],"access")) 
	if (argv[i][0]=='+') showAccess();
	else if (argv[i][0]=='-') hideAccess();
	else returnError("error setting sourceAnchor parameter");

      else if (strstr(argv[i],"invocation")) 
	if (argv[i][0]=='+') showInvocation();
	else if (argv[i][0]=='-') hideInvocation();
	else returnError("error setting sourceAnchor parameter");

      else if (strstr(argv[i],"sourceAnchor")) 
	if (argv[i][0]=='+') showSourceAnchor();
	else if (argv[i][0]=='-') hideSourceAnchor();
	else returnError("error setting sourceAnchor parameter");
      
      else if (strstr(argv[i],"fullInheritanceDef"))
	if (argv[i][0]=='+') showFullInheritanceDefinition();
	else if (argv[i][0]=='-') hideFullInheritanceDefinition();
	else returnError("error setting fullInheritanceDef parameter");

      else if (strstr(argv[i],"packages"))
	if (argv[i][0]=='+') showPackages();
	else if (argv[i][0]=='-') hidePackages();
	else returnError("error setting packages parameter");
      
      else if (strstr(argv[i],"noHeader") || strstr(argv[i],"nh"))
	if (argv[i][0]=='+') showHeader();
	else if (argv[i][0]=='-') hideHeader();
	else returnError("error setting noHeader parameter");
 
      else if (!strcmp(argv[i],"-o"))
	// next parameter should be filename
	if ((i+1)!=argc) { // a next parameter is available
	  outputFileName = argv[++i];
	  // open the file and set output to this file
	  output = fopen(outputFileName,"w"); 
	} else returnError("no filename specified after -o"); 
      

      // assumption: projectnames don't start with '+' or '-' and are
      // always the last parameter
      else if (argv[i][0]=='+' || argv[i][0]=='-' || (i != argc-1))
	returnError(strcat(argv[i],": invalid parameter"));
      else {

		// should be projectname
		projName = argv[i];
		projNameSet = 1;
      } 	
    }
  else { // no parameters given
    usage();
    exit(0);
  }
  
  return readSniffSymbolTable (projName, mainOutput, terminated);
  
  fclose(output); // close output (either file or stdout)

}
















